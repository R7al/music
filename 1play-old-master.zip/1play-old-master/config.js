exports.TOKEN = 'process.env.BOT_TOKEN'; 

exports.PREFIX = '1';

exports.GOOGLE_API_KEY = 'AIzaSyAdORXg7UZUo7sePv97JyoDqtQVi3Ll0b8';
