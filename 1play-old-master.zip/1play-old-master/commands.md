#User
"!userinfo [username or blank]": displays info for the selected user or for message sender if arguments are not provided

#Music
"!play [song name or blank]": plays a song or if arguments are not provided plays the first song in the queue

"!skip": skips the current song

"!queue": displays current queue

"!queue remove [song number]": removes chosen song from the queue

"!queue clear": removes all songs from the queue

"!queue shuffle": shuffles the current queue

"!repeat": plays current song again

"!stop": stops playing music and deletes all songs in the queue

"!yt [search term]": searches the YouTube and returns first 5 results

"!add [search result number]": adds a song from YouTube search to the queue

"!vol [percentage]": sets the volume of the music to given percentage

#Misc
"!help or !commands": displays avialable bot commands